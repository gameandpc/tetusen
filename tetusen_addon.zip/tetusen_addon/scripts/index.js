import { world, system, Player} from '@minecraft/server';
import * as server from '@minecraft/server';


world.afterEvents.chatSend.subscribe((ev) => {
  if(ev.message === "!setup"){

    //赤のシュルカーボックスを使用するプレイヤーの取得
    let redplayers = world.getPlayers({
      scoreOptions: [
          {
              objective : "entry",
              minScore : 1
          }
      ]
  });

  let ashulkerposition = ev.sender.getSpawnPoint()

  ashulkerposition.x = ashulkerposition.x + 20
  ashulkerposition.z = ashulkerposition.z + 4

  for (const rplayer of redplayers) {
  rplayer.setDynamicProperty("vector3", {
    x: ashulkerposition.x,
    y: ashulkerposition.y,
    z: ashulkerposition.z
  });
}

  //紫のシュルカーボックスを使用するプレイヤーの取得
  let purpleplayers = world.getPlayers({
    scoreOptions: [
        {
            objective : "purpleentry",
            minScore : 1
        }
    ]
  });

  let pashulkerposition = ev.sender.getSpawnPoint()

  pashulkerposition.x = pashulkerposition.x + 10
  pashulkerposition.z = pashulkerposition.z + 4

  for (const pplayer of purpleplayers) {
  pplayer.setDynamicProperty("vector3", {
    x: pashulkerposition.x,
    y: pashulkerposition.y,
    z: pashulkerposition.z
  });
}

  //黄のシュルカーボックスを使用するプレイヤーの取得
  let yellowplayers = world.getPlayers({
    scoreOptions: [
        {
            objective : "yellowentry",
            minScore : 1
        }
    ]
  });

  let yashulkerposition = ev.sender.getSpawnPoint()

  yashulkerposition.z = yashulkerposition.z + 4

  for (const yplayer of yellowplayers) {
  yplayer.setDynamicProperty("vector3", {
    x: yashulkerposition.x,
    y: yashulkerposition.y,
    z: yashulkerposition.z
  });
  }


  //青のシュルカーボックスを使用するプレイヤーの取得
  let blueplayers = world.getPlayers({
  scoreOptions: [
      {
          objective : "blueentry",
          minScore : 1
      }
  ]
  });

  let bashulkerposition = ev.sender.getSpawnPoint()

  bashulkerposition.x = bashulkerposition.x - 10
  bashulkerposition.z = bashulkerposition.z + 4

  for (const bplayer of blueplayers) {
  bplayer.setDynamicProperty("vector3", {
    x: bashulkerposition.x,
    y: bashulkerposition.y,
    z: bashulkerposition.z
  });
  }
  
  //桃のシュルカーボックスを使用するプレイヤーの取得
    let pinkplayers = world.getPlayers({
  scoreOptions: [
      {
          objective : "pinkentry",
          minScore : 1
      }
  ]
  });

  let piashulkerposition = ev.sender.getSpawnPoint()

  piashulkerposition.x = piashulkerposition.x - 20
  piashulkerposition.z = piashulkerposition.z + 4

  for (const piplayer of pinkplayers) {
  piplayer.setDynamicProperty("vector3", {
    x: piashulkerposition.x,
    y: piashulkerposition.y,
    z: piashulkerposition.z
  });
}

  }
  }
);


world.afterEvents.chatSend.subscribe((ev) => {
  if(ev.message === "!start"){


server.system.runInterval(ev => {

  //それぞれの色のシュルカーボックスの確認
  let rredplayers = world.getPlayers({
    scoreOptions: [
        {
            objective : "entry",
            minScore : 1
        }
    ]
  });

  let ppurpleplayers = world.getPlayers({
    scoreOptions: [
        {
            objective : "purpleentry",
            minScore : 1
        }
    ]
  });

  let yyellowplayers = world.getPlayers({
    scoreOptions: [
        {
            objective : "yellowentry",
            minScore : 1
        }
    ]
  });

  let bblueplayers = world.getPlayers({
  scoreOptions: [
      {
          objective : "blueentry",
          minScore : 1
      }
  ]
  });
  
  let ppinkplayers = world.getPlayers({
  scoreOptions: [
      {
          objective : "pinkentry",
          minScore : 1
      }
  ]
  });


  //赤のシュルカーボックスの監視

  if (rredplayers.length) {

  rredplayers = rredplayers[0];

  const asshulkerposition = rredplayers.getDynamicProperty("vector3");

  const shulkerblock = world.getDimension("overworld").getBlock(asshulkerposition);

  const tempcontainer = shulkerblock.getComponent('inventory').container;
  let amount = 0;
  for (let i = 0; i < tempcontainer.size; i++) {
      amount += (tempcontainer.getItem(i)?.amount ?? 0);

  }
  
  const iron = world.scoreboard.getObjective("iron");

    iron.setScore(rredplayers, amount);
}

  //紫のシュルカーボックスの監視

  if (ppurpleplayers.length) {

    ppurpleplayers = ppurpleplayers[0];
  
    const purpleshulkerposition = ppurpleplayers.getDynamicProperty("vector3");
  
    const purpleshulkerblock = world.getDimension("overworld").getBlock(purpleshulkerposition);
  
    const purpletempcontainer = purpleshulkerblock.getComponent('inventory').container;
    let purpleamount = 0;
    for (let purplei = 0; purplei < purpletempcontainer.size; purplei++) {
        purpleamount += (purpletempcontainer.getItem(purplei)?.amount ?? 0);
  
    }
    
    const purpleiron = world.scoreboard.getObjective("purpleiron");
  
      purpleiron.setScore(ppurpleplayers, purpleamount);
  }

  //黄のシュルカーボックスの監視

  if (yyellowplayers.length) {

    yyellowplayers = yyellowplayers[0];
  
    const yellowshulkerposition = yyellowplayers.getDynamicProperty("vector3");
  
    const yellowshulkerblock = world.getDimension("overworld").getBlock(yellowshulkerposition);
  
    const yellowtempcontainer = yellowshulkerblock.getComponent('inventory').container;
    let yellowamount = 0;
    for (let yellowi = 0; yellowi < yellowtempcontainer.size; yellowi++) {
        yellowamount += (yellowtempcontainer.getItem(yellowi)?.amount ?? 0);
  
    }
    
    const yellowiron = world.scoreboard.getObjective("yellowiron");
  
      yellowiron.setScore(yyellowplayers, yellowamount);
  }

    //青のシュルカーボックスの監視

    if (bblueplayers.length) {

      bblueplayers = bblueplayers[0];
    
      const blueshulkerposition = bblueplayers.getDynamicProperty("vector3");
    
      const blueshulkerblock = world.getDimension("overworld").getBlock(blueshulkerposition);
    
      const bluetempcontainer = blueshulkerblock.getComponent('inventory').container;
      let blueamount = 0;
      for (let bluei = 0; bluei < bluetempcontainer.size; bluei++) {
          blueamount += (bluetempcontainer.getItem(bluei)?.amount ?? 0);
    
      }
      
      const blueiron = world.scoreboard.getObjective("blueiron");
    
        blueiron.setScore(bblueplayers, blueamount);
    }
  
    //桃のシュルカーボックスの監視

  if (ppinkplayers.length) {

    ppinkplayers = ppinkplayers[0];
  
    const pinkshulkerposition = ppinkplayers.getDynamicProperty("vector3");
  
    const pinkshulkerblock = world.getDimension("overworld").getBlock(pinkshulkerposition);
  
    const pinktempcontainer = pinkshulkerblock.getComponent('inventory').container;
    let pinkamount = 0;
    for (let pinki = 0; pinki < pinktempcontainer.size; pinki++) {
        pinkamount += (pinktempcontainer.getItem(pinki)?.amount ?? 0);
  
    }
    
    const pinkiron = world.scoreboard.getObjective("pinkiron");
  
      pinkiron.setScore(ppinkplayers, pinkamount);
  }
  
});



}
}
);